# https://meta-security-center-checkpoint.auth-portal-secure.net/verify/badge

A Pen created on CodePen.

Original URL: [https://codepen.io/son-son-the-animator/pen/gbwyGXJ](https://codepen.io/son-son-the-animator/pen/gbwyGXJ).

